# DeepFake-Detection
Initial code release for Scientific Reports article
https://doi.org/10.5281/zenodo.19232320
